/*
** EPITECH PROJECT, 2023
** B-CPP-500-PAR-5-2-rtype-luc1.schmitt
** File description:
** collusion
*/

#ifndef COLLUSION_HPP_
#define COLLUSION_HPP_

namespace component {
    class collusion {
        public:
            collusion(){};
            ~collusion(){};
    };
}

#endif /* !COLLUSION_HPP_ */
