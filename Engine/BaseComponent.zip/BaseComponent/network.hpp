/*
** EPITECH PROJECT, 2023
** Engine
** File description:
** network
*/

#ifndef NETWORK_HPP_
#define NETWORK_HPP_

namespace component {
    class network
    {
        private:
            /* data */
        public:
            network(/* args */){}
            ~network(){}
    };
}



#endif /* !NETWORK_HPP_ */
